roulette.js
===========

roulette.js is a jQuery Plugin for roulette image.

### DEMO

http://demo.st-marron.info/roulette/sample/demo.html
