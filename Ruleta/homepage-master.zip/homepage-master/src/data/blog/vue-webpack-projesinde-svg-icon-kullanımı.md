---
title: Vue projesinde svg icon kullanımı
desc: Her başladığım projede ikon kullanımı konusunda türlü yöntemler denedim fakat içime tam olarak sinen bir yöntem bulamamıştım. Github’da bir projenin kodlarını incelerken farklı bir yönteme denk geldim ve uygulayınca gayet mantıklı olduğunu düşündüm.
url: https://medium.com/adem-md/vue-webpack-projesinde-svg-icon-kullan%C4%B1m%C4%B1-k%C4%B1ssakes-528b0e8fd89b
date: 2018-06-17
---
