---
title: Vue projesinde vuex içindeki datayı sıfırlamak
desc: Single Page Application (SPA) geliştirirken sayfa yenilenmediği için bütün datayı yönetmek zorundasınız. Hal böyle olunca login/logout işlemlerinde genelde store’da çıkış yapmış kullanıcının bilgilerini unutabiliyoruz.
url: https://medium.com/adem-md/vue-projesinde-oturum-kapat%C4%B1rken-vuex-i%C3%A7indeki-datay%C4%B1-s%C4%B1f%C4%B1rlamak-5e0fa90fd57e
date: 2018-05-20
---
