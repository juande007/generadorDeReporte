---
title: On yıllıkk tecrübe
desc: Meslek hayatımda tecrübe ettiğim bazı konuları paylaşmak istedim. Bu notların bir kısmında ya yaşayan ya da yaşatan taraf oldum. Amacim sadece sesli dusunmek.
url: https://medium.com/@ademilter/on-yillik-tecrube-b4690c5760d4
date: 2018-09-17
category: popular
---
