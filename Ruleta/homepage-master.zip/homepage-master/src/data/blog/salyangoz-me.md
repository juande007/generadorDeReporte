---
title: 'Salyangoz.me'
desc: Gün içinde internette yüzlerce kaynak geziyorum ve bunların içinden beğendiklerimi insanlarla paylaşmak istiyorum.
url: https://medium.com/turkce/salyangoz-me-471cb480e1f1
date: 2016-06-18
---
