---
title: 'BasitleşMac'
desc: Bir kaç ufak ayar ile daha kullanılabilir bir Mac mümkün.
url: https://medium.com/adem-md/basitle%C5%9Fmac-1b4bb9599825
date: 2016-01-27
category: popular
---
