---
title: Arayüz Tasarımcısına Tavsiyeler — Web
desc: Bu yazı tasarımcıların daha uygulanabilir arayüzler çıkartmasına yardımcı olmak, gelişen ön yüz teknolojileri hakkında fikir sahibi olmasını sağlamak ve ön-yüz geliştiricisine daha iyi işler teslim etmesi için naçizane tavsiyeler içerir.
url: https://medium.com/adem-md/aray%C3%BCz-tasar%C4%B1mc%C4%B1s%C4%B1na-tavsiyeler-web-e65ffee82f83
date: 2018-04-01
category: popular
---
