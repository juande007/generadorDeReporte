---
title: 'Hafta sonu projesi: Namaz Vakti Uygulaması'
desc: Piyasadaki bütün namaz vakti uygulamalarını denemiş biri olarak, hiçbirinden memnun kalmadığımı söyleyebilirim. Hemen hemen hepsi; estetik ve kullanıcı deneyiminden uzak, genelde geliştiriciler tarafından gelişi güzel yapılmış uygulamalardı.
url: https://medium.com/@ademilter/hafta-sonu-projesi-namaz-vakti-uygulamas%C4%B1-182c9e19f862
date: 2017-06-05
category: popular
---
