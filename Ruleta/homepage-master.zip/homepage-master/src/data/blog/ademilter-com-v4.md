---
title: 'ademilter.com — v4'
desc: Kişisel web sitemi iki-üç senede bir yenileme ihtiyacı hissediyorum. Tasarım trendinin değişmesi, frontend tarafının hızlı gelişmesi ve kendimi geliştirmiş olmam sonucu yeni bir arayüze ihtiyaç duyuyorum.
url: https://medium.com/adem-md/ademilter-com-v4-4bc0ce0a1178
date: 2016-10-24
---
