---
title: HTML+CSS Öğreniyoruz
desc: CSS hakkında giriş yapmak isteyen, az bir şeyler bilip de kendini geliştirmek isteyen, backend geliştirici olup da butonun rengini bile değiştirirken sıkıntılar yaşayan veya “ne anlatıyor lan bu kamil” diyerek gelen herkese HTML+CSS eğitimi.
url: https://medium.com/adem-md/html-css-%C3%B6%C4%9Freniyoruz-b3c10f2441a8
date: 2017-11-17
---
