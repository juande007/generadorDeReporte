---
title: 'Bana #keyword seni hatırlatıyor'
desc: Her insanın bir marka olduğunu düşünürüm. Kimi yeni doğmuştur, kimi duyulmamıştır, kimi de sevilen marka olmuştur.
url: https://medium.com/adem-md/bana-keyword-seni-hat%C4%B1rlat%C4%B1yor-d04c61401e73
date: 2018-06-21
---
