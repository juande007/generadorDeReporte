---
title: Vue projesinde global’e sass dosyası eklemek
desc:
url: https://medium.com/adem-md/vue-cli-webpack-projesinde-globale-sass-dosyas%C4%B1-eklemek-k%C4%B1ssakes-5a64320c464f
date: 2018-05-19
---
