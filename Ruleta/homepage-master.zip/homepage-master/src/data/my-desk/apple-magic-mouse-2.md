---
name: Apple Magic Mouse 2
what: Kablosuz Bilgisayar Faresi
photo: ./apple-magic-mouse-2.jpg
category: everywhere
good:
  - test
bad:
  - test
---
