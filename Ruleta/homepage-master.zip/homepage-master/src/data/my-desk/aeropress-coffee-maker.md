---
name: AeroPress Coffee Maker
what: Kahve Yapma Seti
photo: ./aeropress-coffee-maker.jpg
category: home
good:
  - her yere kolay taşınıyor
  - hızlı ve lezzetli kahve yapıyor
bad:
---
