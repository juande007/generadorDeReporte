---
name: Apple AirPods Pro
what: Kablosuz Kulaklık
photo: ./apple-airpods-pro.jpg
category: everywhere
good:
  - test
bad:
  - test
---
