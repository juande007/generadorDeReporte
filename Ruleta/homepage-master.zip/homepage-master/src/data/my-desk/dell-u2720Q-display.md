---
name: Dell U2720Q Display
what: 27inc 4K Monitör
photo: ./dell-u2720Q-display.jpg
category: home
good:
  - test
bad:
  - test
---
