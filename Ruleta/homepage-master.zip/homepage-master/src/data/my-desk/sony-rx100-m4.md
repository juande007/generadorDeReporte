---
name: Sony RX100-M4
what: Fotoğraf Makinası
photo: ./sony-rx100-m4.jpg
category: everywhere
good:
  - test
bad:
  - test
---
