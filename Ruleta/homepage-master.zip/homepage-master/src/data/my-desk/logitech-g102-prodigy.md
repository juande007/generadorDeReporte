---
name: G102 Prodigy Mouse
what: Kablolu Bilgisayar Faresi
photo: ./logitech-g102-prodigy.jpg
category: home
good:
  - test
bad:
  - test
---
