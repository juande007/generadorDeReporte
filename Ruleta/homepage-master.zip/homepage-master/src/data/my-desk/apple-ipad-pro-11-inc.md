---
name: Apple iPad Pro 11inc
what: Profesyonel Tablet
photo: ./apple-ipad-pro-11-inc.jpg
category: everywhere
good:
  - test
bad:
  - test
---
