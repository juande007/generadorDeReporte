---
name: Apple Magic Keyboard
what: Kablosuz Bilgisayar Klavyesi
photo: ./apple-magic-keyboard.jpg
category: home
good:
  - test
bad:
  - test
---
