---
name: Apple MacBook Pro (13-inch, 2017)
what: Dizüstü Bilgisayar
photo: ./apple-macbook-pro-13inc-i7.jpg
category: everywhere
good:
  - test
bad:
  - test
---
