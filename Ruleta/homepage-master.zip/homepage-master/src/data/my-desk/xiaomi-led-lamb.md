---
name: Xiaomi Led Lamb
what: Masaüstü Akıllı LED Lamba
photo: ./xiaomi-led-lamb.jpg
category: home
good:
  - test
bad:
  - test
---
