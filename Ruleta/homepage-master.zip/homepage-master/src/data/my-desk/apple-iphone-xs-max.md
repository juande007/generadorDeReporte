---
name: Apple iPhone XS Max
what: Cep Telefonu
photo: ./apple-iphone-xs-max.jpg
category: everywhere
good:
  - test
bad:
  - test
---
