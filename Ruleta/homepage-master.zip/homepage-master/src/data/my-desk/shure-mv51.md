---
name: Shure MV51 Condenser Microphone
what: Geniş Diyaframlı Kondenser Mikrofon
photo: ./shure-mv51.jpg
category: home
good:
  - test
bad:
  - test
---
