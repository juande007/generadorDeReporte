---
title: "How to emulate hand-drawn shapes / Algorithms behind RoughJS | shihn.ca"
url: "https://shihn.ca/posts/2020/roughjs-algorithms/"
date: 2020-04-30
---
