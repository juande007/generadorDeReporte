---
title: "bored.solutions"
url: "https://bored.solutions/"
date: 2020-04-28
---
