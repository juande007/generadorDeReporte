---
title: "Serdar Kuzuloğlu Hayata Dair Altın Tavsiyeler"
url: "https://www.youtube.com/watch?v=NmjfhPEDlVU&feature=share"
date: 2020-04-29
---
