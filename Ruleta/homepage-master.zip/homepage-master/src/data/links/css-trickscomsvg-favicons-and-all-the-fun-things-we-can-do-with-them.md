---
title: "SVG, Favicons, and All the Fun Things We Can Do With Them | CSS-Tricks"
url: "https://css-tricks.com/svg-favicons-and-all-the-fun-things-we-can-do-with-them/"
date: 2020-04-29
---
