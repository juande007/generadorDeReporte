---
title: "“iPhone Kestirmeler” ile internet geçmişini kaydetmek"
url: "https://medium.com/@ademilter/iphone-kestirmeler-ile-internet-ge%C3%A7mi%C5%9Fini-kaydetmek-304a95780cda"
date: 2020-05-01
---
