---
title: "The Physician (2013) - IMDb"
url: "https://m.imdb.com/title/tt2101473/"
date: 2020-04-30
---
