---
title: "Frametastic for Figma - Plugin to easily test your design in different viewports | Product Hunt"
url: "https://www.producthunt.com/posts/figma-frametastic"
date: 2020-04-30
---
