---
title: "Website Accessibility Checklist (15 Things You Can Improve) | websitesetup.org"
url: "https://websitesetup.org/web-accessibility-checklist/"
date: 2020-04-29
---
