---
title: "Coronavirus Pandemic: Empty Streets in Istanbul - Miki Takes Photos"
url: "https://mikitakesphotos.exposure.co/coronavirus-pandemic-empty-streets-in-istanbul"
date: 2020-04-28
---
