---
title: Büyük babannenin evinde
desc:
location: İstanbul
device: iPhone XS Max
photo: ./vsco5cf7886b63fd2.jpg
url: https://vsco.co/adem/media/5cf788692dd51c7f3b582563
date: 2019-06-05
category: last
---
