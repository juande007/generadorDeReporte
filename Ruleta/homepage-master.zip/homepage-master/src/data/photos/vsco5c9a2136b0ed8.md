---
title: Life in the shade
desc:
location: İstanbul
device: iPhone XS Max
photo: ./vsco5c9a2136b0ed8.jpg
url: https://vsco.co/adem/journal/life-in-the-shade
date: 2019-03-25
category: journal
---
