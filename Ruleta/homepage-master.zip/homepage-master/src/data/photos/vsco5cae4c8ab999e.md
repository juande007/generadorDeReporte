---
title: Tekerlekli kaplan valiz
desc:
location: Londra
device: iPhone 7
photo: ./vsco5cae4c8ab999e.jpg
url: https://vsco.co/adem/media/5cae4c8841a422377741bfb9
date: 2019-04-10
category: last
---
