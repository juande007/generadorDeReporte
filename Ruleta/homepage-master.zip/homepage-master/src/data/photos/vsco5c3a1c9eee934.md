---
title: Kingston nehri
desc:
location: Londra
device: iPhone XS Max
photo: ./vsco5c3a1c9eee934.jpg
url: https://vsco.co/adem/media/5c3a1c9bc9ae0d6b0080e6cb
date: 2019-01-12
category: last
---
