---
title: 15 Temmuz Şehitler Camii
desc:
location: İstanbul
device: iPhone XS Max
photo: ./vsco5dd7f46bab373.jpg
url: https://vsco.co/adem/media/5dd7f463b7bfed0c20b3359e
date: 2019-11-22
category: last
---
