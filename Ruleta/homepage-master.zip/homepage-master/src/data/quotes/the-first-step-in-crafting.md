---
quote: 'İstediğiniz hayatı hazırlamanın ilk adımı, istemediğiniz her şeyden kurtulmaktır.'
author: 'Joshua Becker'
date: 2020-04-25
---
