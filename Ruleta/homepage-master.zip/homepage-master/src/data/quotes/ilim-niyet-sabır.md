---
quote: 'Salih amelde ilim, niyet, sabır ve ihlasın bulunması lazımdır.'
author: 'Muâz b. Cebel'
date: 2020-01-27
---
