---
quote: 'Zamanınız kısıtlı, bu yüzden başkalarının hayatını yaşayarak onu harcamayın.'
author: 'Steve Jobs'
date: 2020-04-23
---
