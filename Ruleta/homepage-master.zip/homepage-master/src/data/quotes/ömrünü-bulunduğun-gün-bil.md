---
quote: 'Bil ki, dünkü gün senin elinden çıktı; yarın ise, senin elinde senet yok ki, ona mâliksin. Öyle ise, hakikî ömrünü bulunduğun gün bil.'
author: 'Said Nursî'
date: 2020-04-24
---
