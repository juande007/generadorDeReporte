---
quote: "If you want extraordinary results, you need to narrow your focus."
author: "@Kpaxs"
date: 2020-04-30
---
