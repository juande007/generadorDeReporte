---
quote: "Felsefeni açıklama. Onu somutlaştır."
author: 'Epictetus'
date: 2020-04-25
---
