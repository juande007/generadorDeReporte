---
quote: 'Bir planınız yoksa, başarısız olamazsınız. Eğer başarısız olmazsan, daha iyi olamazsın.'
author: 'Jack Butcher'
date: 2020-03-01
---
