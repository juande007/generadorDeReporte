---
quote: 'Kötülüğün en sevdiği şey boşluktur.'
author: 'Friedrich Nietzsche'
date: 2020-01-27
---
