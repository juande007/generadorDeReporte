---
title: Tasarıma Üflenen Kutsal Ruh; Front-End
desc:
totalVideo: 1
totalDuration: 110
photo: ./tasarima-uflenen-kutsa-ruh-frontend.jpg
url: https://www.youtube.com/watch?v=Rl-ez7ZSJ4Q
date: 209-10-25
category: conference
---
