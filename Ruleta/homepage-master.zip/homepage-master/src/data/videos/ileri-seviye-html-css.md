---
title: İleri Seviye CSS
desc: 
totalVideo: 5
totalDuration: 486
photo: ./ileri-seviye-html-css.jpg
url: https://www.youtube.com/playlist?list=PLadt0EaV4m3Ae9mBaQNylUKUaFK38F4EB
date: 2017-12-03
category: development
---
