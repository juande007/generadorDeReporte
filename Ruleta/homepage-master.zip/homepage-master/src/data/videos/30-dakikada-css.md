---
title: 30 Dakikada CSS
desc:
totalVideo: 1
totalDuration: 30
photo: ./30-dakikada-css.jpg
url: https://www.youtube.com/watch?v=u2r7AzU-vJ8
date: 2018-12-21
category: conference
---
