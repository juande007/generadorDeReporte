---
title: Frontend Araçları
desc: 
totalVideo: 2
totalDuration: 29
photo: ./frontend-araclari.jpg
url: https://www.youtube.com/playlist?list=PLadt0EaV4m3BfkGLKVFqt8_e_z5NZZdHx
date: 2020-02-21
category: development
---
