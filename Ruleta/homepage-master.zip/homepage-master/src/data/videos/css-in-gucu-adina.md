---
title: CSS'in Gücü Adına
desc:
totalVideo: 1
totalDuration: 36
photo: ./css-in-gucu-adina.jpg
url: https://www.youtube.com/watch?v=dY3glcudCew
date: 2018-07-30
category: conference
---
