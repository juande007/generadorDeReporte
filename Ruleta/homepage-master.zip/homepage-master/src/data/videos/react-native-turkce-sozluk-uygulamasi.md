---
title: React Native ile Mobil Uygulama
desc:
totalVideo: 16
totalDuration: 434
photo: ./react-native-turkce-sozluk-uygulamasi.jpg
url: https://www.youtube.com/playlist?list=PLadt0EaV4m3CWiofBOml0r95OmhiM6I6v
date: 2020-03-15
category: development
---
