---
title: Uygulamalı Figma Eğitimi
desc: 
totalVideo: 5
totalDuration: 154
photo: ./uygulamali-figma-egitimi.jpg
url: https://www.youtube.com/playlist?list=PLadt0EaV4m3BvRYFQxa4w9BWKfrzqC_p6
date: 2020-04-05
category: design
---
