---
title: Akşam Oturması
desc: Dünyanın farklı yerlerinden bir araya gelen beş arkadaşın, tasarım ağırlıklı konuların konuştuğu video serisi.
totalVideo: 12
totalDuration: 999
photo: ./aksam-oturmasi-tasarim-sohbetleri.jpg
url: https://www.youtube.com/playlist?list=PLadt0EaV4m3B7hX1Az5lFNS3RaJIaV8fI
date: 2020-04-02
category: design
---
