---
title: Sıfırdan CSS Eğitim
desc:
totalVideo: 10
totalDuration: 999
photo: ./sifirdan-html-css-egitimi.jpg
url: https://www.youtube.com/playlist?list=PLadt0EaV4m3BX9JaZbKS9B8076bruv93Y
date: 2020-04-17
category: development
---
