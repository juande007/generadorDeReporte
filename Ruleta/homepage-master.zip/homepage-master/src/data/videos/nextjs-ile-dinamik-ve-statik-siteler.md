---
title: Sıfırdan NextJS
desc:
totalVideo: 7
totalDuration: 110
photo: ./nextjs-ile-dinamik-ve-statik-siteler.jpg
url: https://www.youtube.com/playlist?list=PLadt0EaV4m3BvU1uOVHLyxYL2qMQOkQ22
date: 2020-04-08
category: development
---
