---
title: Sıfırdan Sketch Eğitimi
desc: My First Post
totalVideo: 3
totalDuration: 120
photo: ./sifirdan-sketch-egitimi.jpg
url: https://www.youtube.com/playlist?list=PLadt0EaV4m3C9SJKy_649nRtBBFDhN8Nt
date: 2015-12-17
category: design
---
